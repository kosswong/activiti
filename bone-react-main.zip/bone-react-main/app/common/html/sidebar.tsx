import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import MailIcon from '@mui/icons-material/Mail';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ListSubheader from '@mui/material/ListSubheader';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { Link } from "react-router";


export default function Height() {
    const [open, setOpen] = React.useState(true);
    const handleDrawer = () => {
        setOpen(!open);
    };

    return (
        <Drawer
            sx={{
                width: open ? '240px' : '56px',
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                    width: open ? '240px' : '56px',
                    boxSizing: 'border-box',
                },
            }}
            variant="permanent"
            anchor="left"
            elevation={0}
        >
            <Toolbar style={{ justifyContent: 'space-between' }}>
                {open ? <svg id="MUFG Logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 366.85 131.9" style={{ width: '70%' }}>
                    <rect style={{ fill: 'none' }} width="366.85" height="131.9" />
                    <path style={{ fill: '#5a5a5a' }} d="M185.9,89.94V58.68L172.59,78.94h-.27l-13.42-20V89.94h-10v-48h11.18l12.51,20.13L185.1,41.94h10.8v48Zm38.36.55c-12.79,0-20.36-7.14-20.36-21.12V41.94h10V69.09c0,7.76,4.13,11.75,10.49,11.75S234.9,77,234.9,69.44V41.94h10V69C244.9,83.42,237,90.49,224.26,90.49ZM262.9,51.94v10h21v10h-21v18h-10v-48h37v10Zm53.84,38.61c-14.81,0-24.84-10.4-24.84-24.46V66a24.29,24.29,0,0,1,24.78-24.6c8.57,0,13.66,2.31,18.62,6.56l-6.65,7.91C325,52.8,321.9,51,316.4,51c-7.63,0-13.5,6.76-13.5,14.82V66c0,8.73,5.83,15.1,14.27,15.1a17,17,0,0,0,9.73-2.87V71.94h-11v-10h21V83A30.58,30.58,0,0,1,316.74,90.55Z" />
                    <path style={{ fill: '#e60000' }} d="M95.33,30a35.59,35.59,0,0,0-14.68,3.14,36,36,0,1,0,0,65.73A36,36,0,1,0,95.33,30ZM80.65,98.5A32.55,32.55,0,1,1,113.19,66,32.55,32.55,0,0,1,80.65,98.5ZM95.62,66a15,15,0,1,1-15-15A15,15,0,0,1,95.62,66Z" />
                </svg> : null}
                <IconButton
                    aria-label="open drawer"
                    onClick={handleDrawer}
                    edge="start"
                >
                    <MenuIcon />
                </IconButton>
            </Toolbar>
            <List>
                <ListItem disablePadding>
                    <ListItemButton>
                        <ListItemIcon>
                            <CalendarMonthIcon />
                        </ListItemIcon>
                        <ListItemText primary='27-Nov-2024' />
                    </ListItemButton>
                </ListItem>
            </List>
            <Divider />
            <List subheader={
                open ?
                    <ListSubheader component="div" id="nested-list-subheader">
                        Application Menu
                    </ListSubheader>
                    : ''
            }>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/welcome">
                        <ListItemIcon><InboxIcon /></ListItemIcon>
                        <ListItemText primary='Welcome' />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/login">
                        <ListItemIcon><MailIcon /></ListItemIcon>
                        <ListItemText primary='Login' />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/login2">
                        <ListItemIcon><MailIcon /></ListItemIcon>
                        <ListItemText primary='Login 2' />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/auto-cheque">
                        <ListItemIcon><MailIcon /></ListItemIcon>
                        <ListItemText primary='Table test' />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/maintenance">
                        <ListItemIcon><MailIcon /></ListItemIcon>
                        <ListItemText primary='Maintenance' />
                    </ListItemButton>
                </ListItem>
                <ListItem disablePadding>
                    <ListItemButton component={Link} to="/loading">
                        <ListItemIcon><MailIcon /></ListItemIcon>
                        <ListItemText primary='Loading' />
                    </ListItemButton>
                </ListItem>
            </List>
        </Drawer>
    );
}