"use client"
import * as React from 'react';
import Box from '@mui/material/Box';
import Header from './common/html/header'
import SideBar from './common/html/sidebar'
import AutoCheque from './applications/auto-cheque'
import Login from './common/components/loginCtrl'
import Login2 from './common/components/loginJs'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { Maintenance } from './common/html/maintenance';
import Loading from './common/html/loading';
import { Welcome } from './common/html/welcome'

const theme = createTheme({
  palette: {
    primary: {
      light: '#eb3333',
      main: '#e60000',
      dark: '#a10000',
      contrastText: '#fff',
    },
    secondary: {
      light: '#333333',
      main: '#000000',
      dark: '#000000',
      contrastText: '#fff',
    },
  },
});

export default function Page() {
  return (
    <ThemeProvider theme={theme}>
      <BrowserRouter>
        <Box sx={{ display: 'flex' }}>
          <SideBar />
          <Box sx={{ width: 1 }}>
            <Header />
            <Box sx={{ flexGrow: 1, p: 3 }}>
              <Routes>
                <Route path="/" element={<Maintenance />} />
                <Route path="login" element={<Login />} />
                <Route path="login2" element={<Login2 />} />
                <Route path="welcome" element={<Welcome />} />
                <Route path="auto-cheque" element={<AutoCheque />} />
                <Route path="maintenance" element={<Maintenance />} />
                <Route path="loading" element={<Loading />} />
              </Routes>
            </Box>
          </Box>
        </Box>
      </BrowserRouter>
    </ThemeProvider>
  );
}