
import * as React from 'react';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import LogoutIcon from '@mui/icons-material/Logout';
import SettingsIcon from '@mui/icons-material/Settings';

const headerStyle = {
    background: 'linear-gradient(90deg, rgba(255,255,255,1) 19%, #e60000 100%)',
    minHeight: '70px',
    justifyContent: 'space-between'
};

const headerStyle2 = {
    backgroundColor: '#FFFFFF',
    borderBottom: '3px #e60000 solid',
    minHeight: '70px',
    justifyContent: 'space-between'
};

export default function Header() {
    return (
        <Toolbar style={headerStyle2}>
            <Typography variant="h6" noWrap component="div" color="#e60000">
                Home
                <Breadcrumbs>
                    <Typography variant="caption" color="#e60000">Home / AutCheque / Maintenance</Typography>
                </Breadcrumbs>
            </Typography>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Avatar alt="A_206201_name" src="/static/images/avatar/1.jpg" style={{ margin: 10 }} />
                <Box style={{ marginRight: 30 }}>
                    <Typography variant="button" color="#e60000">A_206201_name</Typography>
                    <Typography variant="caption"><br />Hong Kong Branch<br />Last login: 23-Dec-2024 13:47:20</Typography>
                </Box>
                <IconButton color="secondary">
                    <LogoutIcon />
                </IconButton>
                <IconButton color="secondary">
                    <SettingsIcon />
                </IconButton>
            </Box>
        </Toolbar>
    );
}