/**
###############################################################################
# Detail  : BONE i18n service
# Author  : Sunny Kwan
# Date    : 22-Feb-2016
#
# Maintenance History
#=====+================+=============+=========================================
# SID | Name           | Date        | Reason
#=====+================+=============+=========================================
# SK1 | Sunny Kwan     | 22-Feb-2016 | BONE v1.0 initial release
# KW1 | Koss Wong      | 03-Jan-2025 | Angular to React
###############################################################################
*/
import ajaxService from './ajaxService';

interface MessageBundle {
    [key: string]: string;
}

interface ResourceBundle {
    [key: string]: MessageBundle;
}

class I18nService {
    private resBundleMap: Record<string, ResourceBundle> = {};
    private msgBundleMap: Record<string, ResourceBundle> = {};


    async getBundle(lang: string, key: string): Promise<void> {
        if (!this.resBundleMap[key] || !this.msgBundleMap[key]) {
            const response = await ajaxService.NonAuthAjaxPost('AAA', 'FW', 'I18N', { lang, appId: key }, (res) => res);
            this.resBundleMap[key] = response.data.resBundleMap;
            this.msgBundleMap[key] = response.data.msgBundleMap;
        }
    }

    getI18n(appID: string, key: string): string {
        const translations: Record<string, Record<string, string>> = {
            AAA: {
                AAA_LoginHeader: 'Login',
                AAA_UserId: 'User ID',
                AAA_UserPlaceholder: 'Enter your user ID',
                AAA_Password: 'Password',
                AAA_PasswordPlaceholder: 'Enter your password',
                AAA_Login: 'Login',
                AAA0015I: 'Enter your User ID and Password then click login button to get start.',
            },
        };
        return translations[appID]?.[key] || key;
    }
}

const i18nService = new I18nService();
export default i18nService;