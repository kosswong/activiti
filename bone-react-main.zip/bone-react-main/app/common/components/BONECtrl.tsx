export const userData: { [key: string]: string } = {
    name: "GeeksforGeeks",
    category: "Programming",
    language: "TypeScript",
};