import React from 'react';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid2';

export const Welcome: React.FC = () => {
    return (
        <Paper sx={{ flexGrow: 1 }} style={{ padding: '30px' }}>
            <Grid container spacing={3}>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    Welcome to BONE!
                </Grid>
            </Grid>
        </Paper>
    );
};