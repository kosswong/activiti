// LoginForm.tsx
import React from 'react';
import { Paper, TextField, Button, Typography } from '@mui/material';
import Grid from '@mui/material/Grid2';


interface User {
    userId: string;
    password: string;
}

interface LoginFormProps {
    user: User;
    setUser: React.Dispatch<React.SetStateAction<User>>;
    isProcessing: boolean;
    onLogin: (e: React.MouseEvent<HTMLButtonElement>) => void;
    getI18n: (namespace: string, key: string) => string;
}

const LoginHtml: React.FC<LoginFormProps> = ({ user, setUser, isProcessing, onLogin, getI18n }) => {
    return (
        <Paper sx={{ flexGrow: 1 }}>
            <Grid container spacing={3} style={{ padding: '30px' }}>
                <Typography variant="h5" component="h2">
                    {getI18n('AAA', 'AAA_LoginHeader')} example 2
                </Typography>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    {getI18n('AAA', 'AAA0015I')}
                </Grid>
            </Grid>
            <Grid container spacing={3} style={{ padding: '30px' }}>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <TextField
                        label={getI18n('AAA', 'AAA_UserId')}
                        placeholder={getI18n('AAA', 'AAA_UserPlaceholder')}
                        slotProps={{
                            inputLabel: {
                                shrink: true,
                            },
                        }}
                        size="small"
                        value={user.userId}
                        onChange={(e) => setUser({ ...user, userId: e.target.value })}
                        required
                    />
                </Grid>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <TextField
                        label={getI18n('AAA', 'AAA_Password')}
                        placeholder={getI18n('AAA', 'AAA_PasswordPlaceholder')}
                        type="password"
                        slotProps={{
                            inputLabel: {
                                shrink: true,
                            },
                        }}
                        value={user.password}
                        size="small"
                        onChange={(e) => setUser({ ...user, password: e.target.value })}
                        required
                    />
                </Grid>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <Button variant="outlined" type="submit" disabled={isProcessing} style={{ margin: '5px' }} onClick={(e) => { e.preventDefault(); login(); }}>
                        {isProcessing ? 'Logging in...' : 'Login'}
                    </Button>
                </Grid>
            </Grid>
        </Paper>
    );
};

export default LoginHtml;