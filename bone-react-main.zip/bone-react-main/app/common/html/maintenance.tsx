/* 
###############################################################################
# Detail  : BONE maintenance notification page
# Author  : Sunny Kwan
# Date    : 22-Feb-2016
#
# Maintanence History
#=====+================+=============+=========================================
# SID | Name           | Date        | Reason
#=====+================+=============+=========================================
# SK1 | Sunny Kwan     | 22-Feb-2016 | BONE v1.0 initial release
# KW1 | Koss Wong      | 03-Jan-2025 | Angular to React
###############################################################################
 */
import React from 'react';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid2';

export const Maintenance: React.FC = () => {
    return (
        <Paper sx={{ flexGrow: 1 }} style={{ padding: '30px' }}>
            <Grid container spacing={3}>
                <Grid size={12}>
                    <center><h4>The system is under maintenance. </h4></center> <br />
                    <center><h4>系統維護中。 </h4></center><br />
                    <center><h4>系统维护中。 </h4></center><br />
                    <center><h4>システムはメンテナンス中です。</h4></center><br />
                </Grid>
            </Grid>
        </Paper>
    );
};