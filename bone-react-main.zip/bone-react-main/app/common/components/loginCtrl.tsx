import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ajaxService from './ajaxService'; // Adjust the import according to your project structure
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid2';
import Typography from '@mui/material/Typography';
import i18nService from './BONEI18nService';

interface User {
    userId: string;
    password: string;
}

const Login: React.FC = () => {
    const [user, setUser] = useState<User>({ userId: '', password: '' });
    const [isProcessing, setIsProcessing] = useState<boolean>(false);
    const navigate = useNavigate();
    const getI18n = i18nService.getI18n;

    useEffect(() => {
        // Assuming you have a way to check if the user is logged in
        const isNotLoggedIn = true; // Replace with actual check
        if (!isNotLoggedIn) {
            navigate('/main');
        }
    }, [navigate]);

    const loginDone = (response: any) => {
        if (response.executeResult.status === 'SUCCESS') {
            // Assuming you have a way to set login state globally
            // For example, using Context API or Redux
            navigate('/main');
        }
        setIsProcessing(false);
    };

    const login = () => {
        setIsProcessing(true);
        navigate('/welcome');
        setIsProcessing(false);
        //ajaxService.LoginAjaxPost('AAA', 'FW', 'LOGIN', user, loginDone);
    };

    return (
        <Paper sx={{ flexGrow: 1 }}>
            <Grid container spacing={3} style={{ padding: '30px' }}>
                <Typography variant="h5" component="h2">
                    {getI18n('AAA', 'AAA_LoginHeader')}
                </Typography>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    {getI18n('AAA', 'AAA0015I')}
                </Grid>
            </Grid>
            <Grid container spacing={3} style={{ padding: '30px' }}>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <TextField
                        label={getI18n('AAA', 'AAA_UserId')}
                        placeholder={getI18n('AAA', 'AAA_UserPlaceholder')}
                        slotProps={{
                            inputLabel: {
                                shrink: true,
                            },
                        }}
                        size="small"
                        value={user.userId}
                        onChange={(e) => setUser({ ...user, userId: e.target.value })}
                        required
                    />
                </Grid>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <TextField
                        label={getI18n('AAA', 'AAA_Password')}
                        placeholder={getI18n('AAA', 'AAA_PasswordPlaceholder')}
                        type="password"
                        slotProps={{
                            inputLabel: {
                                shrink: true,
                            },
                        }}
                        value={user.password}
                        size="small"
                        onChange={(e) => setUser({ ...user, password: e.target.value })}
                        required
                    />
                </Grid>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    <Button variant="outlined" type="submit" disabled={isProcessing} style={{ margin: '5px' }} onClick={(e) => { e.preventDefault(); login(); }}>
                        {isProcessing ? 'Logging in...' : 'Login'}
                    </Button>
                </Grid>
            </Grid>
        </Paper>
    );
};

export default Login;