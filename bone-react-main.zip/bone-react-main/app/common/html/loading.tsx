import React from 'react';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid2';
import Typography from '@mui/material/Typography';

export default function Loading() {
    return (
        <Paper sx={{ flexGrow: 1 }} style={{ padding: '30px' }}>
            <Grid container spacing={3}>
                <Typography variant="h5" component="h2">
                    Loading...
                </Typography>
                <Grid size={12} style={{ textAlign: 'center' }}>
                    Loading...
                </Grid>
            </Grid>
        </Paper>
    );
};