/**
###############################################################################
# Detail  : Ajax service
# Author  : Sunny Kwan
# Date	: 22-Feb-2016
#
# Maintenance History
#=====+================+=============+=========================================
# SID | Name           | Date        | Reason
#=====+================+=============+=========================================
# SK1 | Sunny Kwan     | 22-Feb-2016 | BONE v1.0 initial release
# GL1 | Garfield Li    | 10-Oct-2017 | Added AuthPost for handling date object
# TW1 | Ted Wang       | 10-Nov-2020 | Added Parameter suppressHandleRtnMsg to AuthPost
# KW1 | Koss Wong      | 03-Jan-2025 | Angular to React
###############################################################################
*/
const API_BASE_URL = './';

interface PostMessage {
    appId: string;
    funcId: string;
    command: string;
    data: any;
    __REQ_INFO?: {
        suppressHandleRtnMsg?: boolean;
    };
}

const format = (obj: any): any => {
    if (obj == null || typeof obj !== 'object') return obj;

    if (obj instanceof Date) {
        const dateObj = new Date(obj);
        return dateObj.getHours() === 0 && dateObj.getMinutes() === 0 &&
            dateObj.getSeconds() === 0 && dateObj.getMilliseconds() === 0
            ? dateObj.toISOString().split('T')[0] // Format as 'yyyy-MM-DD'
            : dateObj;
    }

    if (Array.isArray(obj)) {
        return obj.map(format);
    }

    if (obj instanceof Object) {
        const copy: any = {};
        for (const attr in obj) {
            if (obj.hasOwnProperty(attr)) {
                copy[attr] = format(obj[attr]);
            }
        }
        return copy;
    }

    throw new Error("Unable to copy obj! Its type isn't supported.");
};

const ajaxService = {
    async AuthAjaxPost(appId: string, funcId: string, command: string, data: any, followupFunc: (response: any) => any, isRequiredFormat = true, suppressHandleRtnMsg = false) {
        const postMessage: PostMessage = {
            appId,
            funcId,
            command,
            data: isRequiredFormat ? format(data) : data,
            __REQ_INFO: { suppressHandleRtnMsg }
        };

        const response = await fetch(`${API_BASE_URL}/appl/request`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postMessage)
        });

        const jsonResponse = await response.json();
        return followupFunc(jsonResponse);
    },

    async LoginAjaxPost(appId: string, funcId: string, command: string, data: any, followupFunc: (response: any) => any) {
        return this.AuthAjaxPost(appId, funcId, command, data, followupFunc, false, false);
    },

    async NonAuthAjaxPost(appId: string, funcId: string, command: string, data: any, followupFunc: (response: any) => any) {
        const postMessage: PostMessage = { appId, funcId, command, data };

        const response = await fetch(`${API_BASE_URL}/core/noauthrequest`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postMessage)
        });

        const jsonResponse = await response.json();
        return followupFunc(jsonResponse);
    },

    async DownloadAjaxPost(appId: string, funcId: string, command: string, data: any, followupFunc: (response: any, status: number, headers: Headers) => any) {
        const postMessage: PostMessage = { appId, funcId, command, data };

        const response = await fetch(`${API_BASE_URL}/appl/filedownloadrequest`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(postMessage)
        });

        const blob = await response.blob();
        const status = response.status;
        const headers = response.headers;
        return followupFunc(blob, status, headers);
    },

    // Add other methods similarly...
};

export default ajaxService;