import React from 'react';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid2';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import EnhancedTable from './live-record';

const AutoCheque: React.FC = () => {
    return (
        <Paper sx={{ flexGrow: 1 }} style={{ padding: '30px' }}>
            <Grid container spacing={3}>
                <Box>
                    <Typography variant="h4" component="h2">
                        Instruction Maintenance
                    </Typography>
                    <Typography variant="h6" component="h2">
                        Selection Screen<br /><br />
                    </Typography>
                </Box>
            </Grid>
            <EnhancedTable></EnhancedTable>
        </Paper>
    );
};

export default AutoCheque;