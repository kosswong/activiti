// Login.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ajaxService from './ajaxService'; // Adjust the import according to your project structure
import LoginHtml from './loginHtml';
import i18nService from './BONEI18nService';

interface User {
    userId: string;
    password: string;
}

const Login: React.FC = () => {
    const [user, setUser] = useState<User>({ userId: '', password: '' });
    const [isProcessing, setIsProcessing] = useState<boolean>(false);
    const navigate = useNavigate();
    const getI18n = i18nService.getI18n;

    useEffect(() => {
        const isNotLoggedIn = true; // Replace with actual check
        if (!isNotLoggedIn) {
            navigate('/main');
        }
    }, [navigate]);

    const loginDone = (response: any) => {
        if (response.executeResult.status === 'SUCCESS') {
            navigate('/main');
        }
        setIsProcessing(false);
    };

    const login = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault();
        setIsProcessing(true);
        navigate('/welcome');
        setIsProcessing(false);
        // ajaxService.LoginAjaxPost('AAA', 'FW', 'LOGIN', user, loginDone);
    };

    return (
        <LoginHtml
            user={user}
            setUser={setUser}
            isProcessing={isProcessing}
            onLogin={login}
            getI18n={getI18n}
        />
    );
};

export default Login;