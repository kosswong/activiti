// Its the homepage a.k.a. index page - Koss Wong
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BONE",
  description: "Back Office Network Env",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}
